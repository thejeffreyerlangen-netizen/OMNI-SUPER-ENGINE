#!/usr/bin/env python3
"""
INTEGRATION TEST FOR THE UNIFIED M-DSL BOTTOM-UP STACK (v6.2.0)
Tests Layer 0 SIMD, Layer 1 Compiler, Layer 2 Spec, Layer 3 v6.2 PDE Kernel, and Evaluator.
"""

import unittest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.omni_engine.layer0_simd import BareMetalSIMDEmulator
from src.omni_engine.layer1_compiler import MDSLLoweringCompiler
from src.omni_engine.layer3_pde_kernel import FieldGeometricPDESolver
from src.omni_engine.evaluator import SuperEngineOmniCleanKernelV46, evaluate_gate_status

class TestUnifiedBottomUpStackV62(unittest.TestCase):

    def test_layer0_simd(self):
        simd = BareMetalSIMDEmulator()
        simd.load_quadword_vector([1.0, 2.0, 3.0, 4.0])
        res = simd.execute_vector_fma()
        self.assertEqual(len(res), 20)
        _, det_j = simd.enforce_hardware_symplectic_invariance()
        self.assertAlmostEqual(det_j, 1.0, places=5)

    def test_layer1_compiler(self):
        compiler = MDSLLoweringCompiler()
        spec_path = os.path.join(os.path.dirname(__file__), '..', 'src', 'omni_engine', 'layer2_spec.msl')
        with open(spec_path, "r") as f:
            code = f.read()
        res = compiler.compile_msl_to_irdsl(code)
        self.assertGreater(res["tokens_count"], 0)
        self.assertIn(0x10, res["bytecode"])

    def test_layer3_pde_kernel(self):
        solver = FieldGeometricPDESolver(grid_size=32)
        res = solver.solve_step_sobolev_h2(viscosity=0.001, min_eigenvalue=-0.999)
        self.assertIn("residual", res)
        self.assertLessEqual(res["residual"], 1.75e-7)
        self.assertGreater(res["adaptive_ron_shift"], 0.0)

    def test_evaluator(self):
        kernel = SuperEngineOmniCleanKernelV46()
        eval_res = kernel.run_full_evaluation(residual=1.64e-07)
        self.assertIn("PASSED", eval_res["gate_1_status"])
        self.assertEqual(eval_res["physical_reality_status"], "VERIFIED_STABLE")

if __name__ == "__main__":
    unittest.main()
