#!/usr/bin/env python3
"""
OMNI SUPER ENGINE v6.2.0 - TOP-LEVEL ENTRY POINT & BACKWARD COMPATIBILITY SHIM
Provides unified import access to Layers 0-3 and the Tri-State Physical Gate Evaluator.
"""

from src.omni_engine import (
    BareMetalSIMDEmulator,
    MDSLLoweringCompiler,
    FieldGeometricPDESolver,
    FormulaJugglerAndSynthesizer,
    SuperEngineOmniCleanKernelV46,
    evaluate_gate_status,
    __version__
)

if __name__ == "__main__":
    print(f"==========================================================================")
    print(f" OMNI SUPER ENGINE v{__version__} - MASTER UNIFIED INITIALIZATION")
    print(f"==========================================================================")
    
    # Quick Smoke Test
    simd = BareMetalSIMDEmulator()
    simd.load_quadword_vector([1.0, 2.0, 3.0, 4.0])
    _, det_j = simd.enforce_hardware_symplectic_invariance()
    
    compiler = MDSLLoweringCompiler()
    spec = "apply ronmetrik_ricci_flow\nenforce det(J) == 1.0\ncarrier_frequency 98.112\nadaptive_ron_shift base_eps=0.000981"
    ir_res = compiler.compile_msl_to_irdsl(spec)
    
    solver = FieldGeometricPDESolver()
    pde_res = solver.solve_step_sobolev_h2(viscosity=0.001, min_eigenvalue=-0.999)
    
    kernel = SuperEngineOmniCleanKernelV46()
    eval_res = kernel.run_full_evaluation(residual=pde_res["residual"], det_j=det_j)
    
    print(f" -> Engine Version          : {__version__}")
    print(f" -> Symplectic det(J)       : {det_j:.6f}")
    print(f" -> Compiled Opcodes        : {ir_res['tokens_count']}")
    print(f" -> Sobolev H^2 Norm        : {pde_res['h2_sobolev_norm']}")
    print(f" -> Adaptive Ronmetrik Shift: {pde_res['adaptive_ron_shift']:.6f}")
    print(f" -> Final Residual          : {pde_res['residual']:.2e}")
    print(f" -> Gate Status             : {eval_res['gate_1_status']}")
    print(f" -> Physical Reality        : {eval_res['physical_reality_status']}")
    print(f" -> HMAC Signature          : {eval_res['hmac_signature'][:32]}...")
    print(f"==========================================================================")
