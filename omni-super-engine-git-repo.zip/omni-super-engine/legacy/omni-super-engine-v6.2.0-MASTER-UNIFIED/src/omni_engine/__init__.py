"""
OMNI SUPER ENGINE - MASTER UNIFIED PACKAGE (v6.2.0)
Vereint Layer 0 bis 3, Adaptive Ronmetrik-Kopplung, Lie-Algebra-Symplektisierung,
PDE-Solver, Tri-State Evaluator und Hardware-Brücken.
"""

from .layer0_simd import BareMetalSIMDEmulator
from .layer1_compiler import MDSLLoweringCompiler
from .layer3_pde_kernel import FieldGeometricPDESolver, FormulaJugglerAndSynthesizer
from .evaluator import SuperEngineOmniCleanKernelV46, evaluate_gate_status

__version__ = "6.2.0-PROD"
__all__ = [
    "BareMetalSIMDEmulator",
    "MDSLLoweringCompiler",
    "FieldGeometricPDESolver",
    "FormulaJugglerAndSynthesizer",
    "SuperEngineOmniCleanKernelV46",
    "evaluate_gate_status"
]
