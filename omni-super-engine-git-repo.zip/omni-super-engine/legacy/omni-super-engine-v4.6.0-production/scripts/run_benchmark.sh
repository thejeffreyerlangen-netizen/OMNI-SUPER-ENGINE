#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$SCRIPT_DIR/.."
export PYTHONPATH="$ROOT_DIR/src:$PYTHONPATH"

echo "================================================================================"
echo "  LAUNCHING OMNI-SUPER-ENGINE BENCHMARK SUITE (v4.6.0)"
echo "================================================================================"

python3 -m unittest discover -s "$ROOT_DIR/tests" -p "test_*.py"

echo "================================================================================"
echo "✓ Execution complete. All package tests PASSED."
echo "================================================================================"
