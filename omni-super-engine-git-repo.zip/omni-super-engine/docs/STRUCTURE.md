# Structure map

| Path | Purpose |
|------|---------|
| `src/omni_engine/` | Current Python package (master_v7, core7, mensah_aggregator, …) |
| `tests/` | pytest and standalone validation scripts |
| `docs/` | Status docs, notes, chapter text |
| `data/qe6d/` | Numerical export CSVs |
| `reports/figures/` | PNG phase-space / result images |
| `reports/pdfs/` | PDF reports and treatises |
| `scripts/` | install.sh, run_v7_test_suite.py, utilities |
| `archive/` | Snapshot zip files of past packages |
| `legacy/` | Unpacked historical project trees (v4–v7, mensah, …) |
| `.github/workflows/` | CI workflow |
