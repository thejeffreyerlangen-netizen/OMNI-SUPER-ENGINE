# OMNI Super Engine (v4.6.0)

**Canonical Hardened Release with Tri-State Physical Evaluator & UAFF Forensic Integrity.**

---

## 🛠️ Installation & Usage

```bash
pip install -e .[dev]
pytest
```
