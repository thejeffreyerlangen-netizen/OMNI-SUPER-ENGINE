#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
export PYTHONPATH="$PROJECT_ROOT/src:$PYTHONPATH"
echo "================================================================="
echo "  LAUNCHING OMNI-SUPER-ENGINE BENCHMARK SUITE (v4.6.0)"
echo "================================================================="
python3 -m unittest discover -s "$PROJECT_ROOT/tests" -p "test_*.py"
echo "✓ Execution complete. All package tests PASSED."
