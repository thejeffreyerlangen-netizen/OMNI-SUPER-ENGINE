"""
Tri-State Physical Gate Evaluator for Super Engine Omni v4.6.0
"""

PHYSICAL_COLLAPSE_THRESHOLD = 0.1  # Reale physikalische Toleranzgrenze (z. B. Plasma-Wandkontakt)

def evaluate_gate_status(final_residual, gate_threshold=1e-10):
    """
    Evaluiert das Ergebnis in drei eindeutigen Kategorien:
    1. PASSED: Innerhalb des strengen mathematischen Test-Gates.
    2. FAILED (Numerical Tolerance): Mathe-Gate verfehlt, aber physikalisch vollkommen stabil.
    3. CRITICAL WARNING: Physikalische Kollapsgefahr im echten Reaktor!
    """
    if final_residual <= gate_threshold:
        return f"PASSED ({final_residual:.2e} <= {gate_threshold:.1e} threshold)", "VERIFIED_STABLE"
    
    if final_residual < PHYSICAL_COLLAPSE_THRESHOLD:
        return (
            f"FAILED (Numerical Tolerance: {final_residual:.2e} > {gate_threshold:.1e} threshold)",
            "PHYSICALLY_FEASIBLE_NO_COLLAPSE"
        )
    
    return (
        f"CRITICAL WARNING (PHYSICAL COLLAPSE RISK: {final_residual:.2e} >= {PHYSICAL_COLLAPSE_THRESHOLD})",
        "UNFEASIBLE_REAL_WORLD_COLLAPSE"
    )
