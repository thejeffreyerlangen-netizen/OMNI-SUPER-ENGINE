"""
Omni Super Engine — Canonical Production Package (v4.6.0)
"""

from .kernel import SuperEngineOmniCleanKernelV46
from .evaluator import evaluate_gate_status, PHYSICAL_COLLAPSE_THRESHOLD

__version__ = "4.6.0"
__all__ = [
    "SuperEngineOmniCleanKernelV46",
    "evaluate_gate_status",
    "PHYSICAL_COLLAPSE_THRESHOLD",
]
