import unittest
from omni_engine import SuperEngineOmniCleanKernelV46, evaluate_gate_status

class TestOmniEngine(unittest.TestCase):
    def setUp(self):
        self.kernel = SuperEngineOmniCleanKernelV46()

    def test_ns_sobolev_h2_pass(self):
        res = self.kernel.execute_ns_sobolev_h2()
        self.assertIn('PASSED', res['gate_1_lege_invariant'])
        self.assertEqual(res['physical_reality_status'], 'VERIFIED_STABLE')

    def test_mhd_3d_asym_pass(self):
        res = self.kernel.execute_mhd_3d_asym()
        self.assertIn('PASSED', res['gate_1_lege_invariant'])
        self.assertEqual(res['physical_reality_status'], 'VERIFIED_STABLE')

    def test_gate_evaluator_levels(self):
        msg, status = evaluate_gate_status(1e-12, 1e-10)
        self.assertIn('PASSED', msg)
        self.assertEqual(status, 'VERIFIED_STABLE')

        msg, status = evaluate_gate_status(1e-8, 1e-10)
        self.assertIn('FAILED', msg)
        self.assertEqual(status, 'PHYSICALLY_FEASIBLE_NO_COLLAPSE')

        msg, status = evaluate_gate_status(0.5, 1e-10)
        self.assertIn('CRITICAL WARNING', msg)
        self.assertEqual(status, 'UNFEASIBLE_REAL_WORLD_COLLAPSE')

if __name__ == '__main__':
    unittest.main()
