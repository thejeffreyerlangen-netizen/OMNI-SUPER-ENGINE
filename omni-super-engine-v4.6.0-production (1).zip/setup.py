from setuptools import setup, find_packages

setup(
    name="omni-super-engine",
    version="4.6.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
)
