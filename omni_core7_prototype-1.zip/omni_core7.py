"""OMNI Core 7 prototype: generator-driven symplectic evolution.

This is an exploratory numerical core, not a claim that a particular field
model from Mensah Theory has been derived. The Hamiltonian generator is an
explicit model input until a theory-specific generator is supplied.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Callable
import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.float64]


@dataclass(frozen=True)
class StepReport:
    generator_residual: float
    symplectic_residual_before: float
    symplectic_residual_after: float
    step_matrix_condition: float
    displacement: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


def canonical_J(n: int) -> Array:
    """Return J=[[0,I],[-I,0]] of dimension 2n."""
    if not isinstance(n, int) or n < 1:
        raise ValueError("n must be a positive integer")
    I = np.eye(n, dtype=float)
    Z = np.zeros((n, n), dtype=float)
    return np.block([[Z, I], [-I, Z]])


def _square_even(M: Array, name: str) -> Array:
    A = np.asarray(M, dtype=float)
    if A.ndim != 2 or A.shape[0] != A.shape[1] or A.shape[0] % 2:
        raise ValueError(f"{name} must be a square even-dimensional matrix")
    if not np.all(np.isfinite(A)):
        raise ValueError(f"{name} contains non-finite values")
    return A


def symplectic_residual(S: Array, J: Array) -> float:
    S = _square_even(S, "S")
    J = _square_even(J, "J")
    if S.shape != J.shape:
        raise ValueError("S and J must have the same shape")
    denom = np.linalg.norm(J, ord="fro")
    if denom == 0:
        raise ValueError("J must be nonzero")
    return float(np.linalg.norm(S.T @ J @ S - J, ord="fro") / denom)


def hamiltonian_residual(A: Array, J: Array) -> float:
    """Relative residual for A.T J + J A = 0."""
    A = _square_even(A, "A")
    J = _square_even(J, "J")
    if A.shape != J.shape:
        raise ValueError("A and J must have the same shape")
    denom = max(np.linalg.norm(A, ord="fro") * np.linalg.norm(J, ord="fro"), 1.0)
    return float(np.linalg.norm(A.T @ J + J @ A, ord="fro") / denom)


def generator_from_symmetric_hessian(K: Array, J: Array) -> Array:
    """Construct A=J K. Symmetric K gives a Hamiltonian A for canonical J."""
    K = _square_even(K, "K")
    J = _square_even(J, "J")
    if K.shape != J.shape:
        raise ValueError("K and J must have the same shape")
    symmetry_error = np.linalg.norm(K - K.T, ord="fro")
    if symmetry_error > 1e-12 * max(np.linalg.norm(K, ord="fro"), 1.0):
        raise ValueError("K must be symmetric to construct a Hamiltonian generator")
    if not np.allclose(J.T, -J, atol=1e-12) or not np.allclose(J @ J, -np.eye(J.shape[0]), atol=1e-12):
        raise ValueError("This helper requires canonical J")
    return J @ K


def cayley_operator(A: Array, h: float, *, max_condition: float = 1e12) -> tuple[Array, float]:
    """Compute (I-hA/2)^-1 (I+hA/2), rejecting ill-conditioned solves."""
    A = _square_even(A, "A")
    if not np.isfinite(h) or h == 0:
        raise ValueError("h must be finite and nonzero")
    I = np.eye(A.shape[0])
    left = I - 0.5 * h * A
    right = I + 0.5 * h * A
    condition = float(np.linalg.cond(left))
    if not np.isfinite(condition) or condition > max_condition:
        raise np.linalg.LinAlgError(f"Cayley solve is ill-conditioned (cond={condition:.3e})")
    return np.linalg.solve(left, right), condition


def omni_geometric_step(
    S: Array, A: Array, J: Array, h: float, *, generator_tol: float = 1e-10,
    max_condition: float = 1e12,
) -> tuple[Array, StepReport]:
    """Advance a linear transformation by one generator-driven Cayley step."""
    S = _square_even(S, "S")
    A = _square_even(A, "A")
    J = _square_even(J, "J")
    if S.shape != A.shape or A.shape != J.shape:
        raise ValueError("S, A and J must have identical dimensions")
    ares = hamiltonian_residual(A, J)
    if ares > generator_tol:
        raise ValueError(f"generator is not Hamiltonian within tolerance: {ares:.3e}")
    before = symplectic_residual(S, J)
    C, cond = cayley_operator(A, h, max_condition=max_condition)
    out = C @ S
    after = symplectic_residual(out, J)
    report = StepReport(
        generator_residual=ares,
        symplectic_residual_before=before,
        symplectic_residual_after=after,
        step_matrix_condition=cond,
        displacement=float(np.linalg.norm(out - S, ord="fro")),
    )
    return out, report


def legacy_elementwise_update(M: Array, alpha: float = 0.1, beta: float = 0.001) -> Array:
    """Reproduce the v6.3-style elementwise update for comparison only."""
    M = _square_even(M, "M")
    if not np.isfinite(alpha) or not np.isfinite(beta):
        raise ValueError("alpha and beta must be finite")
    D = M - np.eye(M.shape[0])
    return M - alpha * D - beta * np.sin(D)  # NumPy sine is elementwise.


def demo(seed: int = 2026, n_half: int = 3, h: float = 0.05, steps: int = 20) -> dict[str, Any]:
    """Run a reproducible structural comparison; not a physics benchmark."""
    rng = np.random.default_rng(seed)
    J = canonical_J(n_half)
    raw = rng.normal(size=J.shape)
    K = 0.5 * (raw + raw.T)
    A = generator_from_symmetric_hessian(K, J)
    # Start from the same non-identity symplectic state for both updates.
    S0, _ = cayley_operator(A, 0.1)
    S_cayley = S0.copy()
    S_legacy = S0.copy()
    trajectory = []
    for k in range(steps):
        S_cayley, report = omni_geometric_step(S_cayley, A, J, h)
        S_legacy = legacy_elementwise_update(S_legacy)
        trajectory.append({
            "step": k + 1,
            "cayley_symplectic_residual": symplectic_residual(S_cayley, J),
            "legacy_symplectic_residual": symplectic_residual(S_legacy, J),
            "cayley_displacement_this_step": report.displacement,
        })
    return {
        "seed": seed, "dimension": int(J.shape[0]), "h": h, "steps": steps,
        "generator_residual": hamiltonian_residual(A, J),
        "cayley_final_symplectic_residual": symplectic_residual(S_cayley, J),
        "legacy_final_symplectic_residual": symplectic_residual(S_legacy, J),
        "trajectory": trajectory,
        "interpretation": (
            "Structural comparison only: the two updates encode different dynamics. "
            "This does not establish which one represents the intended Mensah/OMNI field model."
        ),
    }

@dataclass(frozen=True)
class EvolutionReport:
    accepted_steps: int
    rejected_steps: int
    final_time: float
    final_step_size: float
    max_symplectic_residual: float
    max_generator_residual: float
    initial_energy: float
    final_energy: float
    relative_energy_drift: float
    max_accepted_error_estimate: float
    max_rejected_error_estimate: float

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


@dataclass(frozen=True)
class QuadraticHamiltonian:
    """Linear Hamiltonian model H(z)=0.5*z.T@K@z."""
    K: Array

    def __post_init__(self) -> None:
        K = _square_even(self.K, "K")
        err = np.linalg.norm(K - K.T, ord="fro")
        if err > 1e-12 * max(np.linalg.norm(K, ord="fro"), 1.0):
            raise ValueError("K must be symmetric")
        object.__setattr__(self, "K", K.copy())

    @property
    def dimension(self) -> int:
        return int(self.K.shape[0])

    def generator(self, J: Array) -> Array:
        J = _square_even(J, "J")
        if J.shape != self.K.shape:
            raise ValueError("J and K must have identical dimensions")
        if not np.allclose(J.T, -J, atol=1e-12) or np.linalg.matrix_rank(J) != J.shape[0]:
            raise ValueError("J must be skew-symmetric and nonsingular")
        return J @ self.K

    def energy(self, z: Array) -> float:
        z = np.asarray(z, dtype=float)
        if z.ndim != 1 or z.shape[0] != self.dimension or not np.all(np.isfinite(z)):
            raise ValueError("z must be a finite vector matching K")
        return float(0.5 * z @ self.K @ z)

    def gradient(self, z: Array) -> Array:
        return self.K @ z

    def hessian(self, z: Array) -> Array:
        return self.K


@dataclass(frozen=True)
class NonlinearHamiltonian:
    """Nonlinear Hamiltonian callback adapter: H, grad_H, Hessian_H."""
    dimension: int
    H: Callable[[Array], float]
    grad_H: Callable[[Array], Array]
    hess_H: Callable[[Array], Array]

    def __post_init__(self) -> None:
        if not isinstance(self.dimension, int) or self.dimension < 2 or self.dimension % 2:
            raise ValueError("dimension must be a positive even integer")
        if not all(callable(fn) for fn in (self.H, self.grad_H, self.hess_H)):
            raise ValueError("H, grad_H and hess_H must be callable")

    def energy(self, z: Array) -> float:
        value = float(self.H(np.asarray(z, dtype=float)))
        if not np.isfinite(value):
            raise ValueError("Hamiltonian returned non-finite energy")
        return value

    def gradient(self, z: Array) -> Array:
        g = np.asarray(self.grad_H(np.asarray(z, dtype=float)), dtype=float)
        if g.shape != (self.dimension,) or not np.all(np.isfinite(g)):
            raise ValueError("grad_H returned an invalid vector")
        return g

    def hessian(self, z: Array) -> Array:
        H2 = _square_even(self.hess_H(np.asarray(z, dtype=float)), "Hessian")
        if H2.shape != (self.dimension, self.dimension):
            raise ValueError("Hessian returned the wrong dimension")
        asym = np.linalg.norm(H2 - H2.T, ord="fro")
        if asym > 1e-9 * max(np.linalg.norm(H2, ord="fro"), 1.0):
            raise ValueError("Hessian must be symmetric")
        return 0.5 * (H2 + H2.T)


class OMNICore:
    """Adaptive Hamiltonian evolution with tangent-map transport.

    Quadratic models use a direct Cayley step. Nonlinear models use an implicit
    midpoint solve and the associated local Cayley tangent map. The model must
    supply its Hamiltonian, gradient and Hessian; the core does not invent them.
    """
    def __init__(self, model: QuadraticHamiltonian | NonlinearHamiltonian, J: Array):
        self.model = model
        self.J = _square_even(J, "J")
        if self.J.shape != (model.dimension, model.dimension):
            raise ValueError("J and model dimensions differ")
        if not np.allclose(self.J.T, -self.J, atol=1e-12):
            raise ValueError("J must be skew-symmetric")
        if np.linalg.matrix_rank(self.J) != self.J.shape[0]:
            raise ValueError("J must be nonsingular")
        self.A = model.generator(self.J) if isinstance(model, QuadraticHamiltonian) else None
        self.generator_error = hamiltonian_residual(self.A, self.J) if self.A is not None else 0.0
        if self.generator_error > 1e-10:
            raise ValueError("constructed generator failed Hamiltonian condition")

    def _advance(self, z: Array, S: Array, h: float) -> tuple[Array, Array, float, float]:
        if isinstance(self.model, QuadraticHamiltonian):
            C, cond = cayley_operator(self.A, h)
            return C @ z, C @ S, cond, self.generator_error
        m = z.copy()
        I = np.eye(z.size)
        converged = False
        cond = 1.0
        for _ in range(30):
            F = m - z - 0.5 * h * (self.J @ self.model.gradient(m))
            A_mid = self.J @ self.model.hessian(m)
            left = I - 0.5 * h * A_mid
            cond = float(np.linalg.cond(left))
            if not np.isfinite(cond) or cond > 1e12:
                raise np.linalg.LinAlgError("nonlinear midpoint solve is ill-conditioned")
            if np.linalg.norm(F) <= 1e-12 * (1.0 + np.linalg.norm(m)):
                converged = True
                break
            m = m + np.linalg.solve(left, -F)
            if not np.all(np.isfinite(m)):
                raise RuntimeError("nonlinear midpoint iteration diverged")
        if not converged:
            F = m - z - 0.5 * h * (self.J @ self.model.gradient(m))
            if np.linalg.norm(F) > 1e-10 * (1.0 + np.linalg.norm(m)):
                raise RuntimeError("nonlinear midpoint iteration did not converge")
        A_mid = self.J @ self.model.hessian(m)
        left = I - 0.5 * h * A_mid
        right = I + 0.5 * h * A_mid
        cond = float(np.linalg.cond(left))
        if not np.isfinite(cond) or cond > 1e12:
            raise np.linalg.LinAlgError("tangent Cayley solve is ill-conditioned")
        C = np.linalg.solve(left, right)
        return 2.0 * m - z, C @ S, cond, hamiltonian_residual(A_mid, self.J)

    def integrate(
        self, z0: Array, t_final: float, *, h0: float = 0.05,
        rtol: float = 1e-8, atol: float = 1e-11,
        min_step: float = 1e-10, max_step: float | None = None,
        max_steps: int = 100000,
    ) -> tuple[Array, Array, EvolutionReport, list[dict[str, float]]]:
        z = np.asarray(z0, dtype=float).copy()
        if z.ndim != 1 or z.shape[0] != self.model.dimension or not np.all(np.isfinite(z)):
            raise ValueError("z0 must be a finite vector matching model dimension")
        if not np.isfinite(t_final) or t_final < 0:
            raise ValueError("t_final must be finite and nonnegative")
        if not np.isfinite(h0) or h0 <= 0 or rtol <= 0 or atol <= 0:
            raise ValueError("h0, rtol and atol must be positive and finite")
        if min_step <= 0 or not np.isfinite(min_step):
            raise ValueError("min_step must be positive and finite")
        if not isinstance(max_steps, int) or max_steps < 1:
            raise ValueError("max_steps must be a positive integer")
        max_step = float(max_step if max_step is not None else max(h0, t_final if t_final else h0))
        if not np.isfinite(max_step) or max_step <= 0:
            raise ValueError("max_step must be positive and finite")

        S = np.eye(z.size)
        t = 0.0
        h = min(h0, max_step) if t_final > 0 else h0
        accepted = rejected = 0
        max_symp = max_accepted_err = max_rejected_err = 0.0
        max_gen_error = self.generator_error
        initial_energy = self.model.energy(z)
        history: list[dict[str, float]] = [{
            "t": 0.0, "energy": initial_energy,
            "symplectic_residual": symplectic_residual(S, self.J), "step_size": 0.0,
        }]

        while t < t_final:
            if accepted + rejected >= max_steps:
                raise RuntimeError("maximum step count reached before final time")
            h = min(h, max_step, t_final - t)
            if h < min_step and (t_final - t) > 10 * np.finfo(float).eps * max(1.0, t_final):
                raise RuntimeError("adaptive step fell below min_step")
            try:
                z_full, S_full, _, ge0 = self._advance(z, S, h)
                z_half, S_half, _, ge1 = self._advance(z, S, 0.5 * h)
                z_two, S_two, _, ge2 = self._advance(z_half, S_half, 0.5 * h)
                max_gen_error = max(max_gen_error, ge0, ge1, ge2)
            except (np.linalg.LinAlgError, RuntimeError, ValueError):
                rejected += 1
                h *= 0.5
                if h < min_step:
                    raise RuntimeError("step repeatedly failed; reached min_step")
                continue
            state_scale = atol + rtol * max(np.linalg.norm(z_two), np.linalg.norm(z))
            tangent_scale = atol + rtol * max(np.linalg.norm(S_two, ord="fro"), np.linalg.norm(S, ord="fro"))
            err = float(max(
                np.linalg.norm(z_two - z_full) / state_scale,
                np.linalg.norm(S_two - S_full, ord="fro") / tangent_scale,
            ))
            if np.isfinite(err) and err <= 1.0:
                max_accepted_err = max(max_accepted_err, err)
                z, S = z_two, S_two
                t += h
                if t_final - t <= 10 * np.finfo(float).eps * max(1.0, t_final):
                    t = t_final
                accepted += 1
                sr = symplectic_residual(S, self.J)
                max_symp = max(max_symp, sr)
                history.append({"t": float(t), "energy": self.model.energy(z),
                                "symplectic_residual": sr, "step_size": float(h)})
                h *= 2.0 if err == 0 else min(2.0, max(0.5, 0.9 * err ** (-1.0 / 3.0)))
            else:
                rejected += 1
                max_rejected_err = max(max_rejected_err, err if np.isfinite(err) else float("inf"))
                h *= 0.5 if not np.isfinite(err) else max(0.1, min(0.5, 0.9 * err ** (-1.0 / 3.0)))

        final_energy = self.model.energy(z)
        energy_scale = max(abs(initial_energy), np.linalg.norm(z0)**2 * np.finfo(float).eps, 1e-30)
        report = EvolutionReport(
            accepted_steps=accepted, rejected_steps=rejected, final_time=float(t),
            final_step_size=float(h), max_symplectic_residual=float(max_symp),
            max_generator_residual=float(max_gen_error), initial_energy=float(initial_energy),
            final_energy=float(final_energy),
            relative_energy_drift=float(abs(final_energy - initial_energy) / energy_scale),
            max_accepted_error_estimate=float(max_accepted_err),
            max_rejected_error_estimate=float(max_rejected_err),
        )
        return z, S, report, history


if __name__ == "__main__":
    import json
    print(json.dumps(demo(), indent=2))
