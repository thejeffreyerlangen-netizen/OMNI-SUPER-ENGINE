import unittest
import numpy as np
from scipy.linalg import expm

from omni_field_core import QE6DFieldModel, QE6DParameters, OMNIFieldCore, make_stable_coupling

from omni_core7 import (
    canonical_J, hamiltonian_residual, symplectic_residual,
    generator_from_symmetric_hessian, cayley_operator,
    omni_geometric_step, legacy_elementwise_update,
    QuadraticHamiltonian, NonlinearHamiltonian, OMNICore,
)


class TestOmniCore7(unittest.TestCase):
    def setUp(self):
        self.J = canonical_J(2)
        self.rng = np.random.default_rng(1234)
        raw = self.rng.normal(size=(4, 4))
        self.K = (raw + raw.T) / 2
        self.A = generator_from_symmetric_hessian(self.K, self.J)

    def test_canonical_form(self):
        self.assertTrue(np.allclose(self.J.T, -self.J))
        self.assertTrue(np.allclose(self.J @ self.J, -np.eye(4)))

    def test_generator_is_hamiltonian(self):
        self.assertLess(hamiltonian_residual(self.A, self.J), 1e-13)

    def test_cayley_step_preserves_symplecticity(self):
        S = np.eye(4)
        for _ in range(100):
            S, _ = omni_geometric_step(S, self.A, self.J, 0.01)
        self.assertLess(symplectic_residual(S, self.J), 1e-11)

    def test_cayley_second_order_convergence(self):
        exact = expm(0.2 * self.A)
        errors = []
        for h in (0.1, 0.05, 0.025):
            C, _ = cayley_operator(self.A, h)
            steps = round(0.2 / h)
            approx = np.linalg.matrix_power(C, steps)
            errors.append(np.linalg.norm(approx - exact, ord="fro"))
        self.assertGreater(errors[0] / errors[1], 3.5)
        self.assertGreater(errors[1] / errors[2], 3.5)

    def test_rejects_non_hamiltonian_generator(self):
        with self.assertRaises(ValueError):
            omni_geometric_step(np.eye(4), np.eye(4), self.J, 0.1)

    def test_rejects_bad_dimensions(self):
        with self.assertRaises(ValueError):
            canonical_J(0)
        with self.assertRaises(ValueError):
            symplectic_residual(np.eye(3), np.eye(3))

    def test_legacy_update_not_generally_symplectic(self):
        t = 0.7
        R = np.array([[np.cos(t), np.sin(t)], [-np.sin(t), np.cos(t)]])
        S = np.block([[R, np.zeros((2, 2))], [np.zeros((2, 2), dtype=float), R]])
        self.assertLess(symplectic_residual(S, self.J), 1e-12)
        self.assertGreater(symplectic_residual(legacy_elementwise_update(S), self.J), 1e-8)

    def test_quadratic_energy_preserved_by_midpoint_cayley(self):
        raw = self.rng.normal(size=(4, 4))
        K_spd = raw.T @ raw + 0.5 * np.eye(4)
        model = QuadraticHamiltonian(K_spd)
        core = OMNICore(model, self.J)
        z0 = np.array([0.3, -0.7, 1.1, 0.2])
        z, S, report, _ = core.integrate(z0, 2.0, h0=0.05, rtol=1e-8, atol=1e-11)
        self.assertLess(report.relative_energy_drift, 2e-10)
        self.assertLess(symplectic_residual(S, self.J), 1e-9)
        self.assertAlmostEqual(report.final_time, 2.0)

    def test_adaptive_integrator_tracks_exact_linear_flow(self):
        raw = self.rng.normal(size=(4, 4))
        K_spd = raw.T @ raw + 0.5 * np.eye(4)
        model = QuadraticHamiltonian(K_spd)
        core = OMNICore(model, self.J)
        z0 = np.array([0.3, -0.7, 1.1, 0.2])
        z, _, report, history = core.integrate(z0, 0.4, h0=0.1, rtol=1e-8, atol=1e-11)
        exact = expm(0.4 * core.A) @ z0
        self.assertLess(np.linalg.norm(z - exact), 2e-6)
        self.assertGreater(report.accepted_steps, 0)
        self.assertGreater(len(history), 1)


    def test_nonlinear_hamiltonian_core(self):
        # Duffing-type oscillator: H(q,p)=p^2/2+q^2/2+0.1*q^4.
        model = NonlinearHamiltonian(
            dimension=2,
            H=lambda z: 0.5 * z[1]**2 + 0.5 * z[0]**2 + 0.1 * z[0]**4,
            grad_H=lambda z: np.array([z[0] + 0.4 * z[0]**3, z[1]]),
            hess_H=lambda z: np.array([[1.0 + 1.2 * z[0]**2, 0.0], [0.0, 1.0]]),
        )
        J2 = canonical_J(1)
        core = OMNICore(model, J2)
        z0 = np.array([0.8, 0.0])
        z, S, report, history = core.integrate(
            z0, 2.0, h0=0.04, rtol=2e-7, atol=1e-10,
        )
        self.assertTrue(np.all(np.isfinite(z)))
        self.assertTrue(np.all(np.isfinite(S)))
        self.assertLess(report.max_symplectic_residual, 1e-8)
        self.assertLess(report.relative_energy_drift, 2e-4)
        self.assertGreater(report.accepted_steps, 0)
        self.assertGreater(len(history), 2)


    def test_qe6d_analytic_gradient_matches_finite_difference(self):
        rng = np.random.default_rng(77)
        K = make_stable_coupling(5, seed=77)
        params = QE6DParameters(
            k_coupling=0.13, k_spectral=0.07, k_kuramoto=0.03,
            k_topology=0.02, k_neuro=0.006, k_anchor=0.004, k_gradient=0.008,
        )
        model = QE6DFieldModel(K, params)
        q = rng.normal(scale=0.3, size=(5, 3))
        V, grad = model.potential_and_gradient(q)
        eps = 1e-6
        numerical = np.zeros_like(q)
        for idx in np.ndindex(q.shape):
            qp, qm = q.copy(), q.copy()
            qp[idx] += eps
            qm[idx] -= eps
            numerical[idx] = (model.potential_and_gradient(qp)[0] - model.potential_and_gradient(qm)[0]) / (2 * eps)
        self.assertTrue(np.isfinite(V))
        self.assertLess(np.linalg.norm(grad - numerical) / max(np.linalg.norm(numerical), 1.0), 2e-7)

    def test_qe6d_leapfrog_is_time_reversible(self):
        rng = np.random.default_rng(78)
        model = QE6DFieldModel(make_stable_coupling(6, seed=78))
        core = OMNIFieldCore(model)
        q = rng.normal(scale=0.2, size=(6, 3))
        p = rng.normal(scale=0.1, size=(6, 3))
        q1, p1, _ = core.step(q, p, 0.01)
        q2, p2, _ = core.step(q1, p1, -0.01)
        self.assertLess(np.linalg.norm(q2 - q), 2e-12)
        self.assertLess(np.linalg.norm(p2 - p), 2e-12)

    def test_qe6d_energy_error_bounded_over_run(self):
        rng = np.random.default_rng(79)
        model = QE6DFieldModel(make_stable_coupling(12, seed=79))
        core = OMNIFieldCore(model)
        q0 = rng.normal(scale=0.1, size=(12, 3))
        p0 = rng.normal(scale=0.05, size=(12, 3))
        _, _, history = core.run(q0, p0, steps=300, dt=0.01)
        energies = np.array([row["energy"] for row in history])
        rel_max = np.max(np.abs(energies - energies[0])) / max(abs(energies[0]), 1e-30)
        self.assertLess(rel_max, 2e-4)

    def test_rejects_nonsymmetric_hamiltonian_matrix(self):
        K = np.eye(4)
        K[0, 1] = 2.0
        with self.assertRaises(ValueError):
            QuadraticHamiltonian(K)


if __name__ == "__main__":
    unittest.main(verbosity=2)
