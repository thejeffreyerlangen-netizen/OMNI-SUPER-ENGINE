"""Source-faithful QE6D field core for OMNI Core 7.

This module implements the potential and gradient shown in the supplied
Mensah Theory & Super Engine Omni v6.2.0 document's QE6D section. It improves
that implementation's numerical architecture by separating the Hamiltonian
model from the integrator and adding explicit shape/finite checks.

Important scope note: the source document itself leaves the formal derivation
of the Ron metric and master equations as TODO/scaffold. This module therefore
implements the documented computational equations; it does not claim to prove
that those equations follow from the wider theory.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


@dataclass(frozen=True)
class QE6DParameters:
    k_coupling: float = 0.1
    k_spectral: float = 0.05
    k_kuramoto: float = 0.05
    k_topology: float = 0.01
    k_neuro: float = 0.005
    k_anchor: float = 0.001
    k_gradient: float = 0.002

    def __post_init__(self) -> None:
        for name, value in asdict(self).items():
            if not np.isfinite(value):
                raise ValueError(f"{name} must be finite")


@dataclass(frozen=True)
class FieldStepReport:
    energy_before: float
    energy_after: float
    absolute_energy_change: float
    relative_energy_change: float
    q_norm: float
    p_norm: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


class QE6DFieldModel:
    """Separable Hamiltonian H(q,p)=0.5||p||²+V(q), q shape (nodes, 3).

    The three channels are the three engine-signal aggregates in the source
    implementation. The canonical phase-space state is (q,p), with 6*nodes
    scalar coordinates. K must be symmetric so the coupling potential has the
    gradient implemented below.
    """
    def __init__(self, K: FloatArray, params: QE6DParameters | None = None):
        K = np.asarray(K, dtype=float)
        if K.ndim != 2 or K.shape[0] != K.shape[1] or K.shape[0] < 3:
            raise ValueError("K must be a square matrix with at least 3 nodes")
        if not np.all(np.isfinite(K)):
            raise ValueError("K contains non-finite values")
        asym = np.linalg.norm(K - K.T, ord="fro")
        if asym > 1e-11 * max(np.linalg.norm(K, ord="fro"), 1.0):
            raise ValueError("K must be symmetric")
        self.K = 0.5 * (K + K.T)
        self.params = params or QE6DParameters()
        self.n = int(K.shape[0])

    def _field(self, q: FloatArray) -> FloatArray:
        q = np.asarray(q, dtype=float)
        if q.shape != (self.n, 3) or not np.all(np.isfinite(q)):
            raise ValueError(f"q must be a finite array with shape ({self.n}, 3)")
        return q

    @staticmethod
    def laplacian(q: FloatArray) -> FloatArray:
        """Periodic 1D graph Laplacian used in the source QE6D model."""
        return 2.0 * q - np.roll(q, 1, axis=0) - np.roll(q, -1, axis=0)

    @staticmethod
    def neighbor_average(q: FloatArray) -> FloatArray:
        return 0.5 * (np.roll(q, 1, axis=0) + np.roll(q, -1, axis=0))

    def potential_and_gradient(self, q: FloatArray) -> tuple[float, FloatArray]:
        q = self._field(q)
        p = self.params
        Kq = self.K @ q
        Lq = self.laplacian(q)
        nb = self.neighbor_average(q)
        # Stable log(cosh(q)) without overflow for large |q|.
        log_cosh = np.logaddexp(q, -q) - np.log(2.0)
        V = (
            0.5 * p.k_coupling * np.sum(q * Kq)
            + 0.5 * p.k_spectral * np.sum(q * Lq)
            - 0.5 * p.k_kuramoto * np.sum(q[:, :2] * nb[:, :2])
            + 0.25 * p.k_topology * np.sum(q**4)
            + p.k_neuro * np.sum(log_cosh)
            + 0.5 * p.k_anchor * np.sum(q**2)
            - p.k_gradient * np.sum(np.cos(q))
        )
        g = p.k_coupling * Kq + p.k_spectral * Lq
        g[:, :2] -= p.k_kuramoto * nb[:, :2]
        g += (
            p.k_topology * q**3
            + p.k_neuro * np.tanh(q)
            + p.k_anchor * q
            + p.k_gradient * np.sin(q)
        )
        if not np.isfinite(V) or not np.all(np.isfinite(g)):
            raise FloatingPointError("potential or gradient became non-finite")
        return float(V), g

    def energy(self, q: FloatArray, momentum: FloatArray) -> float:
        q = self._field(q)
        momentum = np.asarray(momentum, dtype=float)
        if momentum.shape != q.shape or not np.all(np.isfinite(momentum)):
            raise ValueError("momentum must be finite and have the same shape as q")
        V, _ = self.potential_and_gradient(q)
        return float(0.5 * np.sum(momentum**2) + V)


class OMNIFieldCore:
    """Kick-drift-kick (Störmer-Verlet) evolution for the documented QE6D model.

    For separable H(q,p)=T(p)+V(q), this method is symplectic and reversible
    in exact arithmetic. It generally does not conserve energy exactly at each
    step; instead, energy error should remain bounded for suitable step sizes.
    """
    def __init__(self, model: QE6DFieldModel):
        self.model = model

    def step(self, q: FloatArray, p: FloatArray, dt: float) -> tuple[FloatArray, FloatArray, FieldStepReport]:
        q = self.model._field(q).copy()
        p = np.asarray(p, dtype=float).copy()
        if p.shape != q.shape or not np.all(np.isfinite(p)):
            raise ValueError("p must be finite and have the same shape as q")
        if not np.isfinite(dt) or dt == 0:
            raise ValueError("dt must be finite and nonzero")

        E0 = self.model.energy(q, p)
        _, g0 = self.model.potential_and_gradient(q)
        p_half = p - 0.5 * dt * g0
        q_next = q + dt * p_half
        _, g1 = self.model.potential_and_gradient(q_next)
        p_next = p_half - 0.5 * dt * g1
        E1 = self.model.energy(q_next, p_next)
        denom = max(abs(E0), np.linalg.norm(q)**2 * np.finfo(float).eps, 1e-30)
        report = FieldStepReport(
            energy_before=E0,
            energy_after=E1,
            absolute_energy_change=float(abs(E1 - E0)),
            relative_energy_change=float(abs(E1 - E0) / denom),
            q_norm=float(np.linalg.norm(q_next)),
            p_norm=float(np.linalg.norm(p_next)),
        )
        return q_next, p_next, report

    def run(
        self, q0: FloatArray, p0: FloatArray, *, steps: int, dt: float,
    ) -> tuple[FloatArray, FloatArray, list[dict[str, float]]]:
        if not isinstance(steps, int) or steps < 0:
            raise ValueError("steps must be a nonnegative integer")
        q = self.model._field(q0).copy()
        p = np.asarray(p0, dtype=float).copy()
        if p.shape != q.shape or not np.all(np.isfinite(p)):
            raise ValueError("p0 must be finite and have the same shape as q0")
        history: list[dict[str, float]] = [{
            "step": 0.0, "energy": self.model.energy(q, p),
            "q_norm": float(np.linalg.norm(q)), "p_norm": float(np.linalg.norm(p)),
        }]
        for k in range(steps):
            q, p, _ = self.step(q, p, dt)
            history.append({
                "step": float(k + 1), "energy": self.model.energy(q, p),
                "q_norm": float(np.linalg.norm(q)), "p_norm": float(np.linalg.norm(p)),
            })
        return q, p, history


def make_stable_coupling(n: int, seed: int = 42, diagonal_margin: float = 0.01) -> FloatArray:
    """Reproduce the source's symmetric random coupling construction robustly."""
    if not isinstance(n, int) or n < 3:
        raise ValueError("n must be an integer >= 3")
    if not np.isfinite(diagonal_margin) or diagonal_margin <= 0:
        raise ValueError("diagonal_margin must be positive and finite")
    rng = np.random.default_rng(seed)
    raw = rng.normal(0.0, 1.0, (n, n)) / np.sqrt(n)
    sym = 0.5 * (raw + raw.T)
    min_eigenvalue = float(np.linalg.eigvalsh(sym)[0])
    return sym + (abs(min_eigenvalue) + diagonal_margin) * np.eye(n)
