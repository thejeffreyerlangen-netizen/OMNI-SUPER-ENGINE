# OMNI Core 7 — technical development report

## Executive result

The implementation was advanced in two directions: a reusable geometry-preserving integrator and a source-faithful QE6D field model. This is a stronger foundation than treating the Omni core as a single matrix correction loop.

## What changed

### 1. Generator-driven geometric evolution

`omni_core7.py` now supports:
- quadratic Hamiltonians `H(z)=1/2 zᵀKz`;
- nonlinear Hamiltonians supplied as `H`, gradient, and Hessian callbacks;
- Cayley/implicit-midpoint evolution;
- adaptive step-doubling;
- tangent-map propagation and symplectic residual tracking;
- energy diagnostics and explicit convergence failures.

### 2. Actual QE6D field equations

The supplied v6.2 document contains a concrete `QE6D.potential_and_grad` implementation. Its equations are now isolated in `omni_field_core.py`, with a matching kick-drift-kick Störmer–Verlet integrator. This preserves the documented coupling, spectral Laplacian, neighbor term, quartic topology, `log(cosh)`, anchor, and cosine terms.

### 3. Independent numerical evidence

The test suite includes finite-difference checks of the QE6D gradient, time reversibility, bounded energy drift, Cayley convergence, and symplectic residual checks. The experiments are reproducible from a fixed seed.

## Reproducible results

From `experiment_results.json`:

- 14 unit tests pass.
- QE6D experiment: 64 nodes, 3 channels per node, 384 scalar phase-space coordinates, 500 steps at `dt=0.01`.
- Maximum relative energy drift over the QE6D trajectory: approximately `1.5855e-6`.
- One-step time-reversal error: approximately `1.3010e-18`.
- In a fixed-final-time step-refinement study, halving `dt` reduces maximum relative energy drift by approximately four; the final-state refinement ratio is approximately `4.0001`, consistent with second-order convergence.
- Linear Cayley map symplectic residual: approximately `3.49e-15` after the selected comparison sequence.
- Legacy elementwise update residual in the same structural comparison: approximately `3.84e-3`.

The legacy and Cayley updates encode different dynamics, so that last comparison concerns geometric preservation only; it does not compare physical accuracy apples-to-apples.

## Mathematical interpretation

For a separable Hamiltonian `H(q,p)=T(p)+V(q)`, kick-drift-kick Störmer–Verlet is symplectic and time-reversible in exact arithmetic. Energy is not generally exact at every discrete step, but for suitable step sizes its error typically remains bounded. The observed QE6D energy drift is an empirical result for the selected test, not a universal guarantee.

For a Hamiltonian generator `A`, the Cayley map `C_h=(I-hA/2)⁻¹(I+hA/2)` is symplectic when the relevant inverse exists. The numerical residuals support the implementation for the tested matrices; the second-order convergence experiment is consistent with the expected method order.

## Crucial boundary: the actual Mensah operator

The source describes a Ron metric `g_ij(Ron)=g_ij(0)+R_ij(Ron)`, Einstein–Cartan torsion coupling, a 98.112 Hz carrier, and a QE6D master system. However, the same source marks the formal definitions and derivations as TODO/scaffold. It does not provide a fully specified equation connecting the Ron tensor or carrier to the Hamiltonian/generator used by the core.

For that reason, the code does not invent a carrier coupling or claim that the QE6D equations are formally derived from the broader theory. The next theory-level step is to specify the missing tensor evolution/coupling law, then encode it as the model callbacks and test its gradient, invariants, and limiting cases.

## Recommended next development step

1. Formalize the Ron tensor evolution and its dimensions/units.
2. State how it modifies the QE6D potential or symplectic form.
3. Derive the corresponding energy, gradient, and Hessian (or a valid noncanonical geometric structure).
4. Add a limiting-case test that recovers the current QE6D model when the new coupling is set to zero.
5. Compare against an independent integrator and a step-refinement study.

This is where the true OMNI-specific innovation can enter: not by adding arbitrary parameters, but by implementing the theory's missing operator law in a mathematically testable way.
