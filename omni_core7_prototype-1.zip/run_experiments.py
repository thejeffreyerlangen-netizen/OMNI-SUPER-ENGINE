"""Reproducible numerical experiments for OMNI Core 7.

These experiments validate numerical structure for an explicitly chosen
quadratic Hamiltonian. They do not validate or derive Mensah Theory.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.linalg import expm

from omni_core7 import (
    canonical_J, generator_from_symmetric_hessian, cayley_operator,
    symplectic_residual, hamiltonian_residual, legacy_elementwise_update,
    QuadraticHamiltonian, OMNICore,
)
from omni_field_core import QE6DFieldModel, QE6DParameters, OMNIFieldCore, make_stable_coupling


def main() -> dict:
    rng = np.random.default_rng(20261022)
    J = canonical_J(3)  # six-dimensional phase space
    raw = rng.normal(size=(6, 6))
    K = raw.T @ raw + 0.75 * np.eye(6)  # positive definite quadratic H
    model = QuadraticHamiltonian(K)
    A = model.generator(J)
    z0 = np.array([0.4, -0.2, 0.7, -0.3, 0.5, 0.1])
    S0, _ = cayley_operator(A, 0.03)
    total_time = 0.25
    exact_flow = expm(total_time * A)
    exact_z = exact_flow @ z0

    convergence = []
    for h in (0.05, 0.025, 0.0125, 0.00625):
        C, cond = cayley_operator(A, h)
        steps = round(total_time / h)
        S = np.linalg.matrix_power(C, steps)
        z = S @ z0
        convergence.append({
            "h": h,
            "steps": steps,
            "state_error_vs_matrix_exponential": float(np.linalg.norm(z - exact_z)),
            "map_error_vs_matrix_exponential": float(np.linalg.norm(S - np.linalg.matrix_power(exact_flow, 1))),
            "symplectic_residual": symplectic_residual(S, J),
            "single_step_condition": cond,
        })

    core = OMNICore(model, J)
    z_final, S_final, evolution, history = core.integrate(
        z0, total_time, h0=0.05, rtol=1e-8, atol=1e-11,
    )
    legacy = S0.copy()
    cayley = S0.copy()
    for _ in range(20):
        cayley, _ = core_step(cayley, A, J, 0.01)
        legacy = legacy_elementwise_update(legacy)

    # Source-faithful QE6D field model: separable H(q,p)=||p||^2/2+V(q).
    field_rng = np.random.default_rng(20261022)
    field_n = 64
    field_model = QE6DFieldModel(
        make_stable_coupling(field_n, seed=20261022),
        QE6DParameters(),
    )
    field_core = OMNIFieldCore(field_model)
    q0 = field_rng.normal(scale=0.08, size=(field_n, 3))
    p0 = field_rng.normal(scale=0.04, size=(field_n, 3))
    qf, pf, field_history = field_core.run(q0, p0, steps=500, dt=0.01)
    field_energies = np.asarray([row["energy"] for row in field_history])
    field_energy_scale = max(abs(field_energies[0]), 1e-30)
    field_max_drift = float(np.max(np.abs(field_energies - field_energies[0])) / field_energy_scale)
    q1, p1, _ = field_core.step(q0, p0, 0.01)
    q_back, p_back, _ = field_core.step(q1, p1, -0.01)
    field_reversibility_error = float(max(np.linalg.norm(q_back - q0), np.linalg.norm(p_back - p0)))
    field_refinement = []
    field_final_states = {}
    final_time = 2.0
    for field_dt in (0.02, 0.01, 0.005):
        count = round(final_time / field_dt)
        qx, px, hx = field_core.run(q0, p0, steps=count, dt=field_dt)
        ex = np.asarray([row["energy"] for row in hx])
        field_final_states[field_dt] = np.concatenate([qx.ravel(), px.ravel()])
        field_refinement.append({
            "dt": field_dt,
            "steps": count,
            "max_relative_energy_drift": float(np.max(np.abs(ex - ex[0])) / max(abs(ex[0]), 1e-30)),
        })
    coarse_delta = float(np.linalg.norm(field_final_states[0.02] - field_final_states[0.01]))
    fine_delta = float(np.linalg.norm(field_final_states[0.01] - field_final_states[0.005]))

    result = {
        "title": "OMNI Core 7 numerical experiment",
        "seed": 20261022,
        "phase_space_dimension": 6,
        "model": "H(z)=0.5*z.T@K@z, K symmetric positive definite",
        "model_scope": "test model only; not derived from Mensah Theory",
        "generator_residual": hamiltonian_residual(A, J),
        "initial_energy": model.energy(z0),
        "adaptive_evolution": evolution.to_dict(),
        "adaptive_state_error_vs_matrix_exponential": float(np.linalg.norm(z_final - exact_z)),
        "adaptive_history_points": len(history),
        "fixed_step_convergence": convergence,
        "source_faithful_qe6d_field_model": {
            "nodes": field_n,
            "channels_per_node": 3,
            "phase_space_scalar_dimension": 6 * field_n,
            "integrator": "kick-drift-kick Störmer-Verlet",
            "steps": 500,
            "dt": 0.01,
            "initial_energy": float(field_energies[0]),
            "final_energy": float(field_energies[-1]),
            "max_relative_energy_drift_over_trajectory": field_max_drift,
            "one_step_time_reversal_error": field_reversibility_error,
            "step_refinement_to_final_time_2": field_refinement,
            "coarse_vs_medium_final_state_difference": coarse_delta,
            "medium_vs_fine_final_state_difference": fine_delta,
            "observed_refinement_ratio": float(coarse_delta / fine_delta) if fine_delta else None,
            "interpretation": "Numerical structure test of the QE6D potential/gradient transcribed from the supplied v6.2 document; not a validation of the wider physical theory.",
        },
        "legacy_vs_cayley_structural_comparison": {
            "steps": 20,
            "cayley_symplectic_residual": symplectic_residual(cayley, J),
            "legacy_elementwise_symplectic_residual": symplectic_residual(legacy, J),
            "interpretation": "Different update laws; this compares geometric preservation, not equivalent physical accuracy.",
        },
        "caveat": (
            "The source documents mention a Ron metric and 98.112 Hz carrier, but do not provide a fully specified evolution law mapping them to A(z). "
            "No carrier or Ron-metric term is inserted into the generator without such a law."
        ),
    }
    return result


def core_step(S, A, J, h):
    C, _ = cayley_operator(A, h)
    out = C @ S
    return out, {"symplectic_residual": symplectic_residual(out, J)}


if __name__ == "__main__":
    output = main()
    path = Path(__file__).with_name("experiment_results.json")
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))
