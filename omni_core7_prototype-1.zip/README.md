# OMNI Core 7 — geometric core + QE6D field model

## What is included

This prototype contains two complementary computational cores.

- **`omni_core7.py`**: Cayley-based evolution for quadratic Hamiltonians, an adapter for nonlinear Hamiltonians defined by `H(z)`, `grad_H(z)`, and `Hessian_H(z)`, adaptive step-doubling, tangent-map transport, and symplectic/energy diagnostics.
- **`omni_field_core.py`**: the QE6D potential and analytic gradient shown in the supplied v6.2 document, separated from a kick-drift-kick Störmer–Verlet integrator.
- **`test_omni_core7.py`**: 14 tests, including finite-difference gradient checks, reversibility, energy drift, Cayley convergence, and geometric residuals.
- **`run_experiments.py` / `experiment_results.json`**: deterministic numerical experiments and machine-readable results.

The QE6D field model was implemented from the equations visible in the provided source rather than replacing them with an invented Hamiltonian. The wider theory is not silently claimed to be proven.

## Run it

Python 3.10+, NumPy, and SciPy are required.

```bash
python -m unittest -v
python run_experiments.py
```

## Mathematical core

For `H(z)=0.5*z.T@K@z`, symmetric `K`, and canonical symplectic `J`:

```text
A = J @ K
A.T @ J + J @ A = 0
C_h(A) = solve(I - h*A/2, I + h*A/2)
S_next = C_h(A) @ S
```

The adaptive integrator compares one full step with two half steps, then accepts the two-half-step result. Nonlinear models use an implicit-midpoint solve with a Newton iteration and transport the tangent map using the local Hamiltonian Hessian.

The QE6D model uses the separable Hamiltonian `H(q,p)=0.5*sum(p**2)+V(q)`. Its documented potential contains coupling-matrix, periodic Laplacian, neighbor-average, quartic topology, `log(cosh)`, anchor, and cosine terms. The `log(cosh)` calculation is stabilized using `logaddexp`.

## Verified numerical snapshot

- **14/14 automated tests pass.**
- QE6D experiment: 64 nodes, 3 channels per node (384 scalar phase-space coordinates), 500 steps at `dt=0.01`.
- Maximum relative energy drift over that trajectory: approximately `1.59e-6`.
- One-step forward/backward time-reversal error: approximately `1.3e-18`.
- Halving `dt` from `0.02` to `0.01` to `0.005` reduces maximum relative energy drift by about a factor of four each time; final-state refinement ratio is approximately `4.0001`, consistent with second-order convergence.
- Cayley symplectic residual in the structural comparison: approximately `3.49e-15`; legacy elementwise update residual: approximately `3.84e-3`.

The legacy and Cayley updates encode different dynamics; this last comparison tests geometric preservation, not equivalent physical accuracy.

## What is not fabricated

The supplied source describes a Ron metric `g_ij(Ron)=g_ij(0)+R_ij(Ron)`, Einstein–Cartan torsion coupling, a 98.112 Hz carrier, and a QE6D master system. But formal definitions and derivations are marked as TODO/scaffold, and no complete equation maps the Ron tensor or carrier to the generator `A(z)` or QE6D potential parameters.

Therefore this package does **not** arbitrarily inject 98.112 Hz into the generator. The model/integrator boundaries are ready for that coupling once its equation is specified. That is the next theory-level step: define the Ron tensor evolution and coupling law, derive its gradient/Hessian or noncanonical geometric structure, then test limiting cases and invariants.

## Files

- `omni_core7.py` — Cayley and nonlinear Hamiltonian core
- `omni_field_core.py` — QE6D field model and Störmer–Verlet integrator
- `test_omni_core7.py` — test suite
- `run_experiments.py` — reproducible experiments
- `experiment_results.json` — measured results
- `CORE7_TECHNICAL_REPORT.md` — technical report
- `requirements.txt` — dependencies
